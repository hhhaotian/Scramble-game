package Client;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Button;
import java.awt.Color;
import java.awt.TextArea;
import java.awt.TextField;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.lang.invoke.SwitchPoint;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.*;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



public class MessageListener extends Thread {

	private BufferedReader reader;
	private BufferedWriter writer;
	private JTextArea user;
	private String msg;
	private JSONObject listener;
	private String[][] letter;
	private Grids grids;
	private String clientName;
	private JFrame frame2;
	private JTextArea textArea_1;
	private JTextField txtUsername;
	private JButton btnStart;
	private JButton btnInvite;
	private JButton btnPass;
	private JTextField textField_1;
	private JLabel lblInviteUser;
	private JButton btnQuit_1;
	private ArrayList<String> userList;
	
	//private boolean game_status;
	//private JSONArray player;

	public MessageListener(BufferedReader reader,BufferedWriter writer, JTextArea user, String[][] letter, Grids grids, JFrame frame2, JButton btnStart,
			JButton btnInvite, JButton btnPass,JButton btnQuit_1, JTextArea textArea_1, JTextField textField_1, JTextField txtUsername, JLabel lblInviteUser) {
		this.reader = reader;
		this.writer = writer;
		this.user = user;
		this.letter = new String[20][20];
		this.letter = letter;
		this.grids = grids;
		this.frame2 = frame2;
		this.textArea_1 = textArea_1;
		this.txtUsername = txtUsername;
		this.btnStart = btnStart;
		this.btnInvite = btnInvite;
		this.btnQuit_1 = btnQuit_1;
		this.textField_1 = textField_1;
		this.lblInviteUser = lblInviteUser;
		this.btnPass = btnPass;
		userList = new ArrayList<>();
		//this.game_status = game_status;
		//player = new JSONArray();

	}

	private void updateMatirx(String msg) {
		try {
			JSONObject lis = new JSONObject(msg);
			int x =lis.getInt("x");
			int y =lis.getInt("y");
			String character = (String)lis.get("letter");
			letter[x][y] = character;
			grids.repaint();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

//	private void getUserName(String msg) {
//		try {
//			JSONObject lis = new JSONObject(msg);
//			JSONObject users = lis.getJSONObject("user");
//			Iterator iterator = users.keys();
//			while (iterator.hasNext()) {
//				String userName = (String) iterator.next();
//				user.append(userName+"\n");
//
//			}
//		} catch (JSONException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//	}

	private void getUserName(String msg) {//RYR 2018929
		try {
			JSONObject lis = new JSONObject(msg);
			JSONArray users = lis.getJSONArray("userlist");
			userList.clear();
			for(int i=0; i<users.length(); i++) {
				user.append(users.getString(i)+"\n");
				userList.add(users.getString(i));
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	private void displayScore(String msg) {
		try {
			JSONObject lis = new JSONObject(msg);
			JSONObject score = lis.getJSONObject("scores");
//			String [] result = new String[5];
//			result = score.split(",");
			//user.setText("");
			user.append("---Score---"+"\n");
			System.out.println("---Score---");
			for (int i=0; i<userList.size();i++) {
				String player = userList.get(i).toString();
				user.append(player+"  "+score.getInt(player)+"\n");
				System.out.println(player+"  "+score.getInt(player)+"\n");
				//user.append(player+"  "+score.getString(player)+"\n");
				//user.append(userList.get(i)+" "+score.getString(key));
			}
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void setClientName(String msg) {
		try {
			JSONObject lis = new JSONObject(msg);
			clientName = lis.getString("name");
		}catch (JSONException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public String getClientName() {
		return clientName;
	}



	private void vote(String msg) {
		try {
			JSONObject lis = new JSONObject(msg);
			String word = lis.getString("word");
			String userName = lis.getString("username");
			if(userName.equals(getClientName()))return;//自己不投票
			JFrame voting = new JFrame("Vote");
			voting.setVisible(true);
			voting.setBounds(100, 100, 300, 200);
			voting.getContentPane().setLayout(null);
			JLabel information = new JLabel("The player: "+userName+" input a word "+ word);
			information.setBounds(37, 37, 250, 16);
			voting.getContentPane().add(information);
			JButton agree = new JButton("Agree");
			agree.addMouseListener(new MouseAdapter() {
				@Override
				public void mousePressed(MouseEvent e) {
					JSONObject vote = new JSONObject();
					try {
						vote.put("command", "VOTE");
						vote.put("vote","1");//备注
						String reply = vote.toString();
						writer.write(reply+"\n");
						writer.flush();
						voting.dispose();
					} catch (JSONException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			agree.setBounds(26, 120, 117, 29);
			voting.getContentPane().add(agree);


			JButton disagree = new JButton("Disagree");
			disagree.addMouseListener(new MouseAdapter() {
				@Override
				public void mousePressed(MouseEvent e) {
					JSONObject vote = new JSONObject();
					try {
						vote.put("command", "VOTE");
						vote.put("vote","0");//备注
						String reply = vote.toString();
						writer.write(reply+"\n");
						writer.flush();
						voting.dispose();
					} catch (JSONException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			disagree.setBounds(155, 120, 117, 29);
			voting.getContentPane().add(disagree);


		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void warningWindow(String title, String info) {
		JFrame warning = new JFrame(title);
		warning.setVisible(true);
		warning.setBounds(250, 325, 200, 100);
		warning.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		warning.getContentPane().setLayout(null);

		JLabel lblPleaseConnectTo = new JLabel(info);
		lblPleaseConnectTo.setBounds(25, 6, 169, 34);
		warning.getContentPane().add(lblPleaseConnectTo);

		JButton btnQuit = new JButton("Quit");
		btnQuit.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				warning.dispose();
			}
		});
		btnQuit.setBounds(35, 43, 117, 29);
		warning.getContentPane().add(btnQuit);
	}
	
	private void setDisplay() {
		textArea_1.setVisible(false);
		txtUsername.setVisible(false);
		btnStart.setVisible(false);
		btnInvite.setVisible(false);
		textField_1.setVisible(false);
		lblInviteUser.setVisible(false);
		btnPass.setVisible(true);
		btnQuit_1.setVisible(true);
	}
	
	
	private void gameOver() {
		JFrame gameover = new JFrame("Game OVer");
		gameover.setVisible(true);
		gameover.setBounds(250, 325, 400, 300);
		gameover.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gameover.getContentPane().setLayout(null);
		JTextArea score = new JTextArea();
		score.setBounds(10, 10, 380, 280);
		
	}




//	private void releaceBlock() {
//		game_status = true;
//		warningWindow("info", "It is your turn");
//	}

	public void run() {
		try {
			//String msg;
			//Read messages from the server while the end of the stream is not reached
			System.out.println("listenning...");
			while((msg = reader.readLine()) != null) {
				//user.setText("");
				System.out.println("server msg:"+msg);//ddd
				listener = new JSONObject(msg);
				String command = listener.getString("command");
				switch (command) {
				case "USERLIST":
					user.setText("");
					getUserName(msg);
					break;
				case "FILLCELL":
					updateMatirx(msg);
					break;
				case "VOTE":
					vote(msg);
					break;
				case "SCORES":
					//随时可能push
					System.out.println("Scores arrived!!!"+msg);
					user.setText("");
					setDisplay();
					displayScore(msg);
					break;
				case "GAMEOVER":
					frame2.setTitle("游戏结束了，拜拜，此处没有push分数，因为分数没变化 - "+getClientName());
					frame2.getContentPane().setBackground(new Color(0,0,0));
					break;
				case "RELEASEBLOCK":
					if(listener.getString("playerName").equals(getClientName())){
						ClientLogin.setReleaseBreak();
						// warningWindow("Tips", "Your turn!");根本看不到。。。
						frame2.getContentPane().setBackground(new Color(0, 168, 255));
					}
					break;

				case "NAME":
					setClientName(msg);
					frame2.setTitle("Scrabble - "+getClientName());
					System.out.println("-------\nUser Name: "+ clientName+"\n------");
					break;
					
				

				default:
					break;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
