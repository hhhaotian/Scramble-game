/**
 *@author Yiran Ruan
 *Username YRUAN1
 */
package Server;
import org.json.*;
import java.util.ArrayList;
import java.util.Iterator;

class Game {
	private JSONArray msg;
	private static String[][] cell = new String[20][20];
	private static GamePlatform platform;
	private static boolean status = false;//RYR: identify the game start or not

	private JSONObject jmail = new JSONObject();//for json communication
	private JSONObject scores = new JSONObject();//for recording all players' points
	private int countVotes =0;//for counting the vote
	private int countVoters=0;//for counting how many players voted
	private String whoGetPoints;// who will get points after a poll
	private int howManyPoints;//the length of the word
	private int countPass=0;
	private int countCells=400;
	private int howManyPlayers=0;
	private int curPlayerIndex=0;
	ArrayList<String> players = new ArrayList<String>();
	//如果正在运行游戏，gaming为true, 点击start按钮不会触发START功能，反而报错
	//如果游戏结束，则把gaming修改为true

	public synchronized void start() {
		// platform = new GamePlatform();
		// platform.start();
	}
	public synchronized void commander(String msg){
		try{
			JSONObject msgJson = new JSONObject(msg);
			switch (msgJson.getString("command")) {
				case "START":
					if(!status) {//RYR 2018929
						invite(msgJson);
						// new Thread(new Runnable() {
						// 	@Override
						// 	public void run() {
						// 		start();
						// 	}
						// }).start();
						turnStatus();//RYR 2018929
					}
					break;

				case "FILLCELL":
					fillcell(msgJson);
					break;

				case "VOTE":
					vote(msgJson.getInt("vote"));// 1 means agree,0 means disagree
					break;

				case "PASS":
					pass();
					break;

				default:
					break;
			}
		}catch (Exception er) {
				System.out.println(er.getMessage());
		}
	}
	
	public synchronized void fillcell(JSONObject msgJson){
			this.countPass=0;
			this.countCells--;// When count reaches 0, it will terminate the game
			try{
				int x = msgJson.getInt("x");
				int y = msgJson.getInt("y");
				String direction = msgJson.getString("direction");
				cell[x][y] = msgJson.getString("letter");
				String userIndex=Thread.currentThread().getName();
				initialPoll(userIndex,x,y,direction);
				// push to clients: the update of matrix
				jmail.put("command","FILLCELL");
				jmail.put("x",x);
				jmail.put("y",y);
				jmail.put("letter",cell[x][y]);
				ClientManager.getInstance().send(jmail.toString());
				jmail = new JSONObject();
			}catch(JSONException e){
				 // TODO Auto-generated catch block
				 e.printStackTrace();
			}catch(Exception ex){
			 	ServerGUI.showLog("GameFillCell: "+ex.getMessage());
			}
	}

	public synchronized void invite(JSONObject msgJson) {
		try {
			// String index;
			// String user;
			// int id = 0;
			JSONArray j = msgJson.getJSONArray("user");
			for (int i=0;i<j.length();i++){
				this.howManyPlayers++;
				players.add(j.getString(i));
				this.scores.put(j.getString(i),"0");
			}
			// iterator = Thread.getAllStackTraces().keySet().iterator();
			// while (iterator.hasNext()) {
			// 	UserThreads t = (UserThreads) iterator.next();
			// 	if (t.getName().equals(player.get(id))) {
			// 		PlayerManager.getInstance().online(t);
			// 		id++;
			// 		//set all players' points to 0
			// 		this.scores.put(t.getName(),"0");
			// 	}
			// }
			// System.out.println(howManyPlayers);
			// System.out.println(this.scores);
			pushScores();
			nextPlay();
		} catch (Exception e) {
			// TODO: handle exception
			ServerGUI.showLog("GameInvite: "+e.getMessage());
		}
	}

	public synchronized void pass(){
		this.countPass++;
		if(this.countPass==this.howManyPlayers){
			this.gameOver();// game over method 1
		}else{
			nextPlay();
		}
	}

	public synchronized void nextPlay(){
		try{
			jmail.put("command","RELEASEBLOCK");
			jmail.put("playerName",this.players.get(curPlayerIndex));
			ClientManager.getInstance().send(jmail.toString());
			jmail = new JSONObject();
			curPlayerIndex=(curPlayerIndex==howManyPlayers-1)?0:curPlayerIndex+1;
		}catch(JSONException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public synchronized void pushScores(){
		try{
			jmail.put("command","SCORES");
			jmail.put("scores",this.scores);
			ClientManager.getInstance().send(jmail.toString());
			jmail = new JSONObject();
		}catch(JSONException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public synchronized void initialPoll(String userIndex,int x,int y,String direction){
		//calculating a word for vote
		String word		="";
		String thecell	="";
		int position	=(direction.equals("V"))?y:x;
		for(int i=0;i<20;i++){
			thecell=(direction.equals("V"))?cell[x][i]:cell[i][y];
			if(thecell!= null && !thecell.isEmpty()){
				word+=thecell;
			}else if(i<position){
				word="";
			}else if(i>position){
				break;
			}
		}
		//push to clients: the word to vote
		try{
			jmail.put("command","VOTE");
			jmail.put("word",word);
			jmail.put("username",userIndex);//who get points for this word
			ClientManager.getInstance().send(jmail.toString());
			jmail = new JSONObject();
		}catch(JSONException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//reset all statistics for the poll
		this.countVotes=0;
		this.countVoters=0;
		this.whoGetPoints=userIndex;
		this.howManyPoints=word.length();
	}

	public synchronized void vote(int agree){
		this.countVotes+=agree;
		this.countVoters++;
		if(this.countVoters==this.howManyPlayers-1){
			if(this.countVotes==this.countVoters){
				//Update user's points, otherwise, do nothing
				try{
					int p=this.scores.getInt(this.whoGetPoints)+this.howManyPoints;
					this.scores.put(this.whoGetPoints,p);
					pushScores();
				}catch(JSONException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			//Finish voting, move to next round or game over
			System.out.println(countCells+"cells left.");
			if(countCells==395){//测试的时候可以设置这个数
				this.gameOver();// game over method 2
			}else{
				nextPlay();
			}
		}
	}

	private synchronized void gameOver(){
		try{
			//push to clients: game result
			jmail.put("command","GAMEOVER");
			ClientManager.getInstance().send(jmail.toString());
			jmail = new JSONObject();
			status = false;//RYR 2018929
		}catch(JSONException e){
				// TODO Auto-generated catch block
				e.printStackTrace();
		}
	}

	public synchronized boolean getStatus() {
		return status;
	}//RYR 2018929

	public synchronized void turnStatus() {
		if (status) {
			status = false;
		} else {
			status = true;
		}
	}//RYR 2018929
}
