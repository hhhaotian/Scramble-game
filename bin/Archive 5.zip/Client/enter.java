package Client;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JSplitPane;

public class enter {

	private JFrame InvitationWindow;
	private JTextField Invite_name;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					enter window = new enter();
					window.InvitationWindow.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public enter() {
		inventation_window();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void inventation_window() {
		JFrame gameover = new JFrame("Game OVer");
		gameover.setVisible(true);
		gameover.setBounds(250, 325, 400, 300);
		gameover.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gameover.getContentPane().setLayout(null);
		JTextArea finalDisplay = new JTextArea();
		finalDisplay.setBounds(0, 0, 400, 230);
		gameover.getContentPane().add(finalDisplay);
		//String win = findWinner();
		//finalDisplay.append(win+"\n");
		finalDisplay.append("\n");
		finalDisplay.append("---score---\n");
		//getScore(score, finalDisplay);
		JButton exit = new JButton("EXIT");
		exit.setBounds(160, 240, 80, 23);
		gameover.getContentPane().add(exit);
		exit.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				gameover.dispose();
				//invitationWindow.setVisible(true);
			}
		});
	}
}
