/**
 *@author Yiran Ruan
 *Username YRUAN1
 */
package Server;
import java.io.*;
import java.net.*;
import org.json.JSONObject;


public class UserThreads extends Thread {
	private Game game;
	private Socket client;
	BufferedReader reader;
	BufferedWriter writer;
	private boolean status = false; // true -> current player; flase -> watcher
	private boolean identifier = true; // true -> player; flase -> watcher //?wait for complete:
	//ClientManager users = new ClientManager();


	public UserThreads(Socket client, Game game) {
		try{
			this.client = client;
			this.game = game;
		} catch (Exception e){
			System.out.println("client socket");
			e.printStackTrace();
		}
	}

	public void run() {
		try {
			String msg = null;
			String gameMsg = "Pipe Complete";//delete?
			reader = new BufferedReader(new InputStreamReader(client.getInputStream(),"UTF-8"));
			while ((msg = reader.readLine()) != null) {
				System.out.println("User msg:"+msg);
				game.commander(msg);
			}
		} catch (SocketException ex) {
			try {
				reader.close();
				writer.close();
				client.close();
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
		} catch (IOException ioe) {
			System.out.println(ioe.getMessage());
		} catch (Exception er) {
			System.out.println(er.getMessage());
		}

	}


	public void write(String msg) {
		try {
			writer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream(),"UTF-8"));
			writer.write(msg + "\n");//json?
			writer.flush();
			// System.out.println(Thread.currentThread().getName() + " - Message sent to client ");
		} catch (IOException e) {
			e.printStackTrace();//Exception
		}
	}

	public void Block() {
		try {
			JSONObject msg = new JSONObject();
			msg.put("command", "BLOCK");
			writer.write(msg.toString()+"\n");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();//Exception
		} catch (Exception ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();//Exception
		}
	}

	public void turnStatus() {
		System.out.println("Thread TTS");
		try {
			JSONObject msg = new JSONObject();
			msg.put("command", "RELEASEBLOCK");
			if (status) {
				//writer.write("Block"+"\n");//json
				status = false;
			} else {
				writer.write(msg.toString()+"\n");
				writer.flush();
				status = true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace(); // Exception
		}
	}

	public boolean getStatus() {
		return status;
	}
}
