package Client;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.util.Iterator;
import java.util.Iterator;

import javax.swing.JPanel;

import org.json.JSONException;
import org.json.JSONObject;

public class Grids extends JPanel {
	
	final static int ROW = 20;
	final static int SPAN = 25;
	
	private int x;
	private int y;
	private Graphics g;
	static private String[][] letter=null;
	//private JSONObject input;
	
	public Grids(int x, int y, String[][] letter) {
		// TODO Auto-generated constructor stub
		this.x = x;
		this.y = y;
		this.letter = new String[20][20];
		//writeLetter(letter);
		this.letter = letter;
		//this.letter[1][1] = "A";
		//System.out.println(letter.toString());
//		input = new JSONObject();
//		try {
//			input.put("x",2);
//			input.put("y", 3);
//			input.put("char", "J");
//		} catch (JSONException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
	}
	
	//private String
	
//	public void writeLetter(String[][] matrix) {
//		for(int i =0; i<20; i++) {
//			for(int j = 0; j < 20; j++) {
//				this.letter[i][j]=matrix[i][j];
//			}
//		}
//		System.out.println("copy");
//	}
//	
	
	
	public void drawGrid(int x,int y,Graphics g) {
		
		for(int i=0;i<=ROW;i++)
		{
			g.drawLine(x, y+i*SPAN, SPAN*ROW,y+i*SPAN);
			//if(letter[i][j].isEmpty())
		}
		
		for(int i=0;i<=ROW;i++)
		{
			g.drawLine(x+i*SPAN, y, x+i*SPAN,SPAN*ROW);
		}
		
		for (int i=0; i<ROW; i++) {
			for (int j=0; j<ROW; j++) {
				if(letter[i][j] == null) {
					//System.out.println("no character");
					continue;
				}
				else {
					drawStr(i, j, letter[i][j].toString(), g);
				}
				
			}
		}
		
		//g.drawString("a", 35, 17);
		//drawStr(1, 2, "B",g);
		//System.out.println(letter[2][1]==null);
//		Iterator iterator = new Iterator() {
//		};


	}
	
	public void drawStr(int x, int y, String letter, Graphics g) {
		int point_x = 10 + x*SPAN;
		int point_y = 17 + y*SPAN;
		//int point_x = x;
		//int point_y = y;
		//System.out.println("x2:"+point_x+"y2:"+point_y+"letter"+letter.getClass());
		
		g.drawString(letter, point_x, point_y);
		
	}
	
	public void paint(Graphics g) {
		super.paint(g);
		this.drawGrid(x, y, g);
//		int point_x = 10 + x*SPAN;
//		int point_y = 17 + y*SPAN;
//		g.drawString("A", point_x, point_y);
	}
	
	


}






