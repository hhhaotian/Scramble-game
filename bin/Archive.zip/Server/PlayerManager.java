package Server;

import java.util.ArrayList;
import java.util.List;

//Singleton object in charge of processing messages received from
//clients and managing the server state
public class PlayerManager {

	private static PlayerManager instance;

	private static List<UserThreads> onlinePlayers;

	private PlayerManager() {
		onlinePlayers = new ArrayList<UserThreads>();
	}

	public static synchronized PlayerManager getInstance() {
		if(instance == null) {
			instance = new PlayerManager();
		}
		return instance;
	}

	public synchronized void online(UserThreads player) {
		onlinePlayers.add(player);
	}

	public synchronized void offline(UserThreads player) {
		onlinePlayers.remove(player);
	}

	public synchronized List<UserThreads> getOnlinePlayers() {
		return onlinePlayers;
	}

	public synchronized int countPlayer() {
		return onlinePlayers.size();
	}
	
	public synchronized void reset() {
		onlinePlayers.clear();
	}

}
