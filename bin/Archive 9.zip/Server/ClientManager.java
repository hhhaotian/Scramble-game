package Server;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


//Singleton object in charge of processing messages received from
//clients and managing the server state
public class ClientManager {

	private static ClientManager instance;
	private static List<UserThreads> connectedClients;

	private ClientManager() {
		connectedClients = new ArrayList<UserThreads>();

	}

	public static synchronized ClientManager getInstance() {
		if(instance == null) {
			instance = new ClientManager();
		}
		return instance;
	}

	public synchronized void send(String msg) {
		// Broadcast the client message to all the clients connected
		// to the server
		for(UserThreads UserThreads : connectedClients) {
			UserThreads.write(msg);
		}
	}

	public synchronized void clientConnected(UserThreads ut) {
		try {
			connectedClients.add(ut);
			JSONObject msgJSON = new JSONObject();
			msgJSON.put("command", "USERLIST");
			JSONArray userlist = new JSONArray();
			ServerGUI.showLog(ut.getName()+" have connected.");
			ServerGUI.clearPleayer();

			/*JSONObject yourName = new JSONObject();
			yourName.put("command", "NAME");
			yourName.put("name", ut.getName());
			ut.write(yourName.toString());*/

			for(UserThreads UserThreads : connectedClients) {
				ServerGUI.showPlayer(UserThreads.getName());
				userlist.put(UserThreads.getName());
			}
			msgJSON.put("userlist", userlist);
			for(UserThreads UserThreads : connectedClients) {
				 UserThreads.write(msgJSON.toString());
			}
			ServerGUI.showLog(userlist+"has been sent.");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public synchronized void clientDisconnected(UserThreads ut) {
		try {
			connectedClients.remove(ut);
			JSONObject msgJSON = new JSONObject();
			msgJSON.put("command", "USERLIST");
			JSONArray userlist = new JSONArray();
			ServerGUI.showLog(ut.getName()+" has leaved.");
			ServerGUI.clearPleayer();
			for(UserThreads UserThreads : connectedClients) {
				ServerGUI.showPlayer(UserThreads.getName());
				userlist.put(UserThreads.getName());
			}
			msgJSON.put("userlist", userlist);
			for(UserThreads UserThreads : connectedClients) {
				UserThreads.write(msgJSON.toString());
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public synchronized List<UserThreads> getConnectedClients() {
		return connectedClients;
	}

	public synchronized void reset() { //RYR Oct1
		connectedClients.clear();
	}

}
