package Client;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JRadioButton;

public class enter {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					enter window = new enter();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public enter() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 300, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblInputALetter = new JLabel("Input a letter");
		lblInputALetter.setBounds(37, 37, 118, 16);
		frame.getContentPane().add(lblInputALetter);
		
		textField = new JTextField();
		textField.setBounds(166, 32, 77, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnConfirm = new JButton("Confirm");
		btnConfirm.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		btnConfirm.setBounds(26, 120, 117, 29);
		frame.getContentPane().add(btnConfirm);
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBounds(155, 120, 117, 29);
		frame.getContentPane().add(btnCancel);
		
		JRadioButton rdbtnHorizontal = new JRadioButton("Horizontal");
		rdbtnHorizontal.setBounds(47, 65, 141, 23);
		frame.getContentPane().add(rdbtnHorizontal);
		
		JRadioButton rdbtnVertical = new JRadioButton("Vertical");
		rdbtnVertical.setBounds(47, 85, 141, 23);
		frame.getContentPane().add(rdbtnVertical);
	}
}
