package Server;

public class GamePlatform {//new thread?
	private boolean moveOnOnce=false;
	private static int passCount = 0;
	private boolean signal = true;
	public void start() {
		while (signal/*keep game*/) {
			// for(UserThreads t : PlayerManager.getInstance().getOnlinePlayers()) {
			// 	t.turnStatus();
			// 	while (t.getStatus()){
			// 		if(this.moveOnOnce){//break the while and move to the next player
			// 			t.turnStatus();
			// 			this.moveOnOnce=false;
			// 		}
			// 	}
			// 	t.Block();
			// }
		}
	}

	public synchronized void moveOn(){
		this.moveOnOnce=true;
	}

}
