package Client;

import java.sql.ResultSet;

public class MatrixManage {

	private String[][] matrix;

	public MatrixManage(String[][] matrix) {
		// TODO Auto-generated constructor stub
		this.matrix = new String[20][20];
		this.matrix = matrix;
	}

	public boolean isValid(int x, int y) {
		if(matrix[x][y]==null) {
			return true;
		}
		else {
			return false;
		}
	}

	public void addValue(int x, int y,String value) {
		matrix[x][y] = value;

	}

	public String modifyInput(String input) {
		String output = input;
		if(output.length()>1) {
			output = output.substring(0,1);

		}
		output = output.toUpperCase();
		return output;
	}
	
	public void resetMatix() {
		for (int i = 0 ; i < 20; i++) {
			for (int j = 0; j < 20 ; j++) {
				matrix[i][j] = null;
			}
		}
		System.out.println("reset matrix");
	}

}
