package Client;

import java.awt.Color;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.IOException;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GameUI {
	
	private BufferedWriter writer;
	private JFrame frame2;
	private Grids grids;
	private JButton btnPass;
	private JButton btnQuit_1;
	private String direction=null;
	private int point_x;
	private int point_y;
	private String character=null;
	private MatrixManage matrix_manage;
	private static boolean game_status = false;
	private static boolean wait_status = true;
	private String clientName;
	private String[][] letter;
	private JSONObject send;
	private JSONArray userList;
	private JTextArea textArea;
	private MessageListener ml;
	

	public GameUI(String[][] letter, BufferedWriter writer) {
		// TODO Auto-generated constructor stub
		//frame2 = new JFrame();
		this.letter = new String[20][20];
		this.letter = letter;
		this.writer = writer;
		//ml = new MessageListener(frame2, textArea);
	}
	
	public GameUI() {
		frame2 = new JFrame();
		System.out.println("invoce in ml");
	}
	
	public void addUser(String userName) {
		userList.put(userName);
		/*RYR Oct1
		 for (int i = 0; i < userList.length(); i++) {
			try {
				if (userList.get(i).equals(userName)) {
					break;
				} else {
					userList.put(userName);
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		 */
	}
	
	public static void setReleaseBreak() {
		game_status = true;
	}
	
	public static void blockUsers() {
		game_status = false;
	}
	
	public static void setWaitStatus() {
		System.out.println("Start game");
		wait_status = false;
	}


	private void addChar(int x, int y, String letter) {

			this.letter[x][y] = letter;

	}
	
	public void setTitle(String title) {
		frame2.setTitle(title);
	}
	
	public void setVisible() {
		frame2.setVisible(true);
	}
	
	public void warningWindow(String title, String info) {
		JFrame warning = new JFrame(title);
		warning.setVisible(true);
		warning.setBounds(250, 325, 200, 100);
		warning.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		warning.getContentPane().setLayout(null);

		JLabel lblPleaseConnectTo = new JLabel(info);
		lblPleaseConnectTo.setBounds(25, 6, 169, 34);
		warning.getContentPane().add(lblPleaseConnectTo);

		JButton btnQuit = new JButton("Quit");
		btnQuit.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				warning.dispose();
			}
		});
		btnQuit.setBounds(35, 43, 117, 29);
		warning.getContentPane().add(btnQuit);
	}
	
	public void gameStart() {
		//matrix_manage.resetMatix();
		
		frame2.getContentPane().setBackground(new Color(238,238,238));
		frame2.setTitle(clientName);
		frame2.setBounds(100, 100, 800, 570);
		frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame2.getContentPane().setLayout(null);


		grids = new Grids(1,1,letter);
		grids.setBounds(20, 20, 525, 525);
		frame2.getContentPane().add(grids);
		grids.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if(game_status == true) {
					point_x=e.getX()/25;
					point_y=e.getY()/25;
					if(point_x == 20) {
						point_x = 19;
					}
					if(point_y == 20) { 
						point_y = 19;
					}
					//grids.paint(point_x,p);
					if(matrix_manage.isValid(point_x, point_y)) {
						JFrame addChar = new JFrame("input a character");
						addChar.getContentPane().setLayout(null);
						addChar.setBounds(100,100,300,200);
						addChar.setVisible(true);
						JLabel info = new JLabel("input a letter at "+point_x+","+point_y);
						info.setBounds(26, 30, 150, 16);
						JTextField enter = new JTextField();
						enter.setBounds(179, 28, 77, 26);
						addChar.getContentPane().add(info);
						addChar.getContentPane().add(enter);
						JButton btnConfirm = new JButton("Submit");

						JRadioButton rdbtnVertical = new JRadioButton("Vertical");
						rdbtnVertical.addItemListener(new ItemListener() {
							public void itemStateChanged(ItemEvent e) {
								direction = "V";
							}
						});
						rdbtnVertical.setBounds(47, 85, 141, 23);
						addChar.getContentPane().add(rdbtnVertical);


						JRadioButton rdbtnHorizontal = new JRadioButton("Horizontal");
						rdbtnHorizontal.addItemListener(new ItemListener() {
							public void itemStateChanged(ItemEvent e) {
								direction = "H";
							}
						});
						rdbtnHorizontal.setBounds(47, 65, 141, 23);
						addChar.getContentPane().add(rdbtnHorizontal);

						ButtonGroup group = new ButtonGroup();
						group.add(rdbtnHorizontal);
						group.add(rdbtnVertical);

						btnConfirm.addMouseListener(new MouseAdapter() {
							@Override
							public void mousePressed(MouseEvent e) {
								character = enter.getText();
								character = matrix_manage.modifyInput(character);
								addChar(point_x, point_y, character);
								grids.repaint();
								addChar.dispose();

								try {
									if (direction == null) {
										direction = "H";
									}
									send.put("command", "FILLCELL");
									send.put("direction", direction);
									send.put("x", Integer.toString(point_x));
									send.put("y", Integer.toString(point_y));
									send.put("letter", character);
									String command = send.toString();
									writer.write(command+"\n");
									writer.flush();
								} catch (JSONException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								} catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
								game_status = false;
								frame2.getContentPane().setBackground(new Color(238,238,238));
							}
						});
						btnConfirm.setBounds(26, 108, 117, 29);
						addChar.getContentPane().add(btnConfirm);
						JButton btnCancel = new JButton("Cancel");
						btnCancel.setBounds(155, 108, 117, 29);
						addChar.getContentPane().add(btnCancel);
						btnCancel.addMouseListener(new MouseAdapter() {
							public void mousePressed(MouseEvent e) {
								addChar.dispose();
							}
						});
					}
					else {
						//JFrame errorInfo = new JFrame("Invalid Enter");
						warningWindow("Invalid Enter", "Select another place!");
					}
				}
				else {
					warningWindow("Warning", "You cannot enter now!");
				}




			}
		});

		textArea = new JTextArea();
		textArea.setBounds(563, 53, 186, 400);
		frame2.getContentPane().add(textArea);
		textArea.setEditable(false);


		
		
		btnPass = new JButton("PASS");
		btnPass.setBounds(597, 307, 119, 29);
		btnPass.setVisible(true);
		frame2.getContentPane().add(btnPass);
		btnPass.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if(game_status) {
					try {
						send.put("command", "PASS");
						String command = send.toString();
						writer.write(command+"\n");
						writer.flush();
						
					} catch (JSONException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}catch(IOException e1) {
						e1.printStackTrace();
					}
					
					frame2.getContentPane().setBackground(new Color(238,238,238));
				}
				
			}
		});
		

		JLabel lblUserList = new JLabel("Information Board");
		lblUserList.setBounds(563, 25, 136, 16);
		frame2.getContentPane().add(lblUserList);


		
		JScrollPane scrollPane = new JScrollPane(textArea);/////////wait
		scrollPane.setBounds(563, 53, 186, 203);
		frame2.getContentPane().add(scrollPane);
		scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		

		
		btnQuit_1 = new JButton("QUIT");    //CLIENT QUIT THE GAME
		btnQuit_1.setVisible(true);
		btnQuit_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
			}
		});
		btnQuit_1.setBounds(597, 358, 119, 29);
		frame2.getContentPane().add(btnQuit_1);

	}

}
