/**
 *@author Yiran Ruan
 *Username YRUAN1
 */
package Server;
import java.io.*;
import java.net.*;
import java.util.ArrayList;

import org.json.JSONObject;


public class GameServer implements Runnable {
	private Game game = new Game();
	private int port;
	private ServerSocket server = null;
	private int clientNum = 0;
	private boolean power;
	private ArrayList<String> nameList = new ArrayList<String>();

	public GameServer (int port) {
		this.port = port;
		System.out.println("------\nServer Console\n------");
		game.gameReset();
	}

	public void run() throws NullPointerException{

		try {
			server = new ServerSocket(port);
			ServerGUI.showLog("Server listening on port "+port+" for a connection");
			power = true;
			while(power){
				BufferedReader reader;
				BufferedWriter writer;
				String username;
				ClientManager.getInstance();
				Socket client = server.accept();
				ServerGUI.showLog(Thread.currentThread().getName()+ " - Client conection accepted");
				clientNum++;
				reader = new BufferedReader(new InputStreamReader(client.getInputStream(),"UTF-8"));
				username = reader.readLine();
				writer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream(),"UTF-8"));
				JSONObject msgName = new JSONObject();
				if (username.equals("\n") || username.isEmpty()|| username==null) {
					ServerGUI.showLog(clientNum+" is connecting");
					UserThreads user = new UserThreads(client, game);
					user.setName("a" + clientNum);//final改
					nameList.add(user.getName());
					msgName.put("command", "NAME");
					msgName.put("name", user.getName());
					writer.write(msgName.toString()+"\n");
					writer.flush();
					user.start();
					ClientManager.getInstance().clientConnected(user);
				} else {
					if(isExist(username)) {
						msgName.put("command", "DUPLICATENAME");
						writer.write(msgName.toString()+"\n");
						writer.flush();
						//client.close();
					} else {
						ServerGUI.showLog(clientNum+" is connecting");
						UserThreads user = new UserThreads(client, game);
						user.setName(username);
						msgName.put("command", "NAME");
						msgName.put("name", user.getName());
						writer.write(msgName.toString()+"\n");
						writer.flush();
						user.start();//RYR 20180929
						ClientManager.getInstance().clientConnected(user);
					}
				}





			}
		} catch (Exception ex2){
			//ex2.printStackTrace();
			ServerGUI.showLog("Socket:"+ex2.getMessage());
		} finally {
			try {
				server.close();
			} catch (IOException e) {
				ServerGUI.showLog(e.getMessage());
			} catch (NullPointerException ex) {
				throw new NullPointerException(ex.getMessage());
			}
		}
	}

	public void stopServer() {
		try {
			ServerGUI.showLog("Server is closed. See you next time");
			server.close();
			power = false;
			clientNum = 0;
		} catch (IOException e) {
			ServerGUI.showLog(e.getMessage());
		}
	}

	public int getClientNum() {
		return clientNum;
	}

	private boolean isExist(String name) {
		for(int i = 0; i<nameList.size();i++) {
			if (nameList.get(i).equals(name)) {
				return true;
			}
		}
		nameList.add(name);
		return false;
	}
}
