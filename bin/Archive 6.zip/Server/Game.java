/**
 *@author Yiran Ruan
 *Username YRUAN1
 */
package Server;
import org.json.*;
import java.util.ArrayList;
import java.util.Iterator;

class Game {
	private JSONArray msg;
//	private static GamePlatform platform;
	private static String[][] cell;
	private boolean gameStatus;//RYR: identify the game start or not
	private JSONObject jmail;//for json communication
	private JSONObject scores;//for recording all players' points
	private String whoGetPoints;// who will get points after a poll
	private int countVotes;//for counting the vote
	private int countVoters;//for counting how many players voted
	private int howManyPoints;//the length of the word
	private int countPass;
	private int countCells;
	private int howManyPlayers;
	private int curPlayerIndex;
	ArrayList<String> players = new ArrayList<String>();

	public synchronized void start() {
		// platform = new GamePlatform();
		// platform.start();
	}

	public synchronized void gameReset(){
		this.cell = new String[20][20];
		this.gameStatus = false;
		this.jmail = new JSONObject();
		this.scores = new JSONObject();
		this.whoGetPoints="";
		this.countVotes =0;
		this.countVoters=0;
		this.howManyPoints=0;
		this.countPass=0;
		this.countCells=400;
		this.howManyPlayers=0;
		this.curPlayerIndex=0;
	}

	public synchronized void commander(String msg){
		try{
			JSONObject msgJson = new JSONObject(msg);
			switch (msgJson.getString("command")) {
				case "START":
					if(!gameStatus) {//RYR 2018929
						invite(msgJson);
						// new Thread(new Runnable() {
						// 	@Override
						// 	public void run() {
						// 		start();
						// 	}
						// }).start();
						turnStatus();//RYR 2018929
					}
					break;

				case "FILLCELL":
					fillcell(msgJson);
					break;

				case "VOTE":
					vote(msgJson.getInt("vote"));// 1 means agree,0 means disagree
					break;

				case "PASS":
					pass();
					break;

				default:
					break;
			}
		}catch (Exception er) {
				System.out.println(er.getMessage());
		}
	}

	public synchronized void pushScores(){
		try{
			jmail.put("command","SCORES");
			jmail.put("scores",this.scores);
			ClientManager.getInstance().send(jmail.toString());
			jmail = new JSONObject();
		}catch(JSONException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public synchronized void invite(JSONObject msgJson) {
		try {
			// String index;
			// String user;
			// int id = 0;
			JSONArray j = msgJson.getJSONArray("user");
			for (int i=0;i<j.length();i++){
				this.howManyPlayers++;
				players.add(j.getString(i));
				this.scores.put(j.getString(i),0);
			}
			// iterator = Thread.getAllStackTraces().keySet().iterator();
			// while (iterator.hasNext()) {
			// 	UserThreads t = (UserThreads) iterator.next();
			// 	if (t.getName().equals(player.get(id))) {
			// 		PlayerManager.getInstance().online(t);
			// 		id++;
			// 		//set all players' points to 0
			// 		this.scores.put(t.getName(),"0");
			// 	}
			// }
			// System.out.println(howManyPlayers);
			// System.out.println(this.scores);
			pushScores();
			nextPlay();
		} catch (Exception e) {
			// TODO: handle exception
			ServerGUI.showLog("GameInvite: "+e.getMessage());
		}
	}

	public synchronized void fillcell(JSONObject msgJson){
			this.countPass=0;
			this.countCells--;// When count reaches 0, it will terminate the game
			try{
				int x = msgJson.getInt("x");
				int y = msgJson.getInt("y");
				cell[x][y] = msgJson.getString("letter");
				String direction = msgJson.getString("direction");
				// push to clients: the update of matrix
				jmail.put("command","FILLCELL");
				jmail.put("x",x);
				jmail.put("y",y);
				jmail.put("letter",cell[x][y]);
				ClientManager.getInstance().send(jmail.toString());
				jmail = new JSONObject();
				if(direction.equals("N")){//方向要是N就不投票
					nextPlay();
				}else{
					String userIndex=Thread.currentThread().getName();
					initialPoll(userIndex,x,y,direction);
				}
			}catch(JSONException e){
				 // TODO Auto-generated catch block
				 e.printStackTrace();
			}catch(Exception ex){
			 	ServerGUI.showLog("GameFillCell: "+ex.getMessage());
			}
	}

	public synchronized void initialPoll(String userIndex,int x,int y,String direction){
		//calculating a word for vote
		String word		="";
		String thecell	="";
		int position	=(direction.equals("V"))?y:x;
		for(int i=0;i<20;i++){
			thecell=(direction.equals("V"))?cell[x][i]:cell[i][y];
			if(thecell!= null && !thecell.isEmpty()){
				word+=thecell;
			}else if(i<position){
				word="";
			}else if(i>position){
				break;
			}
		}
		//push to clients: the word to vote
		try{
			jmail.put("command","VOTE");
			jmail.put("word",word);
			jmail.put("username",userIndex);//who get points for this word
			ClientManager.getInstance().send(jmail.toString());
			jmail = new JSONObject();
		}catch(JSONException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//reset all statistics for the poll
		this.countVotes=0;
		this.countVoters=0;
		this.whoGetPoints=userIndex;
		this.howManyPoints=word.length();
	}

	public synchronized void vote(int agree){
		this.countVotes+=agree;
		this.countVoters++;
		if(this.countVoters==this.howManyPlayers-1){
			if(this.countVotes==this.countVoters){
				//Update user's points, otherwise, do nothing
				try{
					int p=this.scores.getInt(this.whoGetPoints)+this.howManyPoints;
					this.scores.put(this.whoGetPoints,p);
					pushScores();
				}catch(JSONException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			//Finish voting, move to next round or game over
			nextPlay();
		}
	}

	public synchronized void pass(){
		this.countPass++;
		if(this.countPass==this.howManyPlayers){
			this.gameOver();// game over method 1
		}else{
			nextPlay();
		}
	}

	public synchronized void nextPlay(){
		System.out.println(countCells+"cells left.");
		if(countCells==395){//final 测试的时候可以设置这个数
			this.gameOver();// game over method 2
		}else{
			try{
				jmail.put("command","RELEASEBLOCK");
				jmail.put("playerName",this.players.get(curPlayerIndex));
				ClientManager.getInstance().send(jmail.toString());
				jmail = new JSONObject();
				curPlayerIndex=(curPlayerIndex==howManyPlayers-1)?0:curPlayerIndex+1;
			}catch(JSONException e){
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private synchronized void gameOver(){
		try{
			//push to clients: game result
			jmail.put("command","GAMEOVER");
			ClientManager.getInstance().send(jmail.toString());
			jmail = new JSONObject();
			gameStatus = false;//RYR 2018929
		}catch(JSONException e){
				// TODO Auto-generated catch block
				e.printStackTrace();
		}
		gameReset();
	}

	public synchronized void peaceOut(){
		if(gameStatus){
			gameOver();
		}
	}

	public synchronized boolean getStatus() {
		return gameStatus;
	}//RYR 2018929

	public synchronized void turnStatus() {
		if (gameStatus) {
			gameStatus = false;
		} else {
			gameStatus = true;
		}
	}//RYR 2018929
}
